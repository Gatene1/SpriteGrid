function allocSheet(cols, rows) {
    sheetCols = cols;
    sheetRows = rows;

    sheetOcc = new Int32Array(cols * rows);
    sheetOcc.fill(-1);

    sprites = [];
    selectedSprites.clear();
    selectedSpriteId = -1;
    hoveredSpriteId = -1;

    spriteCanvas.width = sheetCols * spriteCellSize;
    spriteCanvas.height = sheetRows * spriteCellSize;
}

function cellIndex(x, y) {
    return y * sheetCols + x;
}

function cellToXY(idx) {
    return {
        x: idx % sheetCols,
        y: Math.floor(idx / sheetCols)
    };
}

function canPlaceRect(x, y, w, h) {
    if (x < 0 || y < 0) return false;
    if (x + w > sheetCols) return false;
    if (y + h > sheetRows) return false;

    for (let yy = 0; yy < h; yy++) {
        for (let xx = 0; xx < w; xx++) {
            if (sheetOcc[cellIndex(x + xx, y + yy)] !== -1) {
                return false;
            }
        }
    }
    return true;
}

function stampRect(x, y, w, h, value) {
    for (let yy = 0; yy < h; yy++) {
        for (let xx = 0; xx < w; xx++) {
            sheetOcc[cellIndex(x + xx, y + yy)] = value;
        }
    }
}

function exitImportMode() {
    mouseSprite = null;
    spriteHeld = false;
    pasteSprite = false;
}

function addSpriteFromMouse(mouse, x, y) {
    const id = sprites.length;

    sprites.push({
        id,
        wPx: mouse.wPx,
        hPx: mouse.hPx,
        pixels: mouse.pixels,
        wCells: mouse.wCells,
        hCells: mouse.hCells,
        xCell: x,
        yCell: y
    });

    stampRect(x, y, mouse.wCells, mouse.hCells, id);

    selectedSprites.clear();
    selectedSprites.add(id);
    selectedSpriteId = id;

    return id;
}

function tryPlaceMouseSpriteAtCellIndex(idx) {
    if (!mouseSprite || !pasteSprite) return false;

    const { x, y } = cellToXY(idx);

    if (!canPlaceRect(x, y, mouseSprite.wCells, mouseSprite.hCells)) {
        return false;
    }

    addSpriteFromMouse(mouseSprite, x, y);
    exitImportMode();
    return true;
}

function eraseSpriteById(id) {
    const s = sprites[id];
    if (!s) return;

    stampRect(s.xCell, s.yCell, s.wCells, s.hCells, -1);
    sprites[id] = null;

    selectedSprites.delete(id);
    if (selectedSpriteId === id) selectedSpriteId = -1;
}

function spriteSheetClick() {
    if (spriteCellOn < 0) return;

    if (spriteHeld && pasteSprite) {
        tryPlaceMouseSpriteAtCellIndex(spriteCellOn);
        drawAll();
        return;
    }

    if (eraseTool) {
        const id = sheetOcc[spriteCellOn];
        if (id !== -1) eraseSpriteById(id);
        drawAll();
        return;
    }

    const id = sheetOcc[spriteCellOn];
    selectedSprites.clear();
    if (id !== -1) {
        selectedSprites.add(id);
        selectedSpriteId = id;
    } else {
        selectedSpriteId = -1;
    }
    console.log("spriteCellOn", spriteCellOn, "occ", sheetOcc?.[spriteCellOn]);

    drawAll();
}

function rebuildSheetOccFromSprites() {
    if (!sheetOcc) return;
    sheetOcc.fill(-1);

    for (let id = 0; id < sprites.length; id++) {
        const s = sprites[id];
        if (!s) continue;

        // Ensure id matches array index (your current convention)
        stampRectOcc(s.xCell, s.yCell, s.wCells, s.hCells, id);
    }
}
